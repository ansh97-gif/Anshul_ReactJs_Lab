import React,{useState} from "react"
import { Box, Modal } from "@mui/material";
import './addExpense.css';
import { putDataIntoServer } from "../../service/service";
import TextField from "@mui/material";
const AddExpense = (props) => {
 const [payload,setPayload]=useState({});


  const handleSubmit=(e)=>{
    e.preventDefault();
    if(!(payload.payeeName&&payload.payeeName.length>0)){ 
      window.alert("Payee is empty");
      return;
    }
    if(!(payload.product&&payload.product.length>0)){ 
      window.alert("Product is empty");
      return;
    }

    if(payload.price&&parseInt(payload.price)<=0){
      window.alert("Price should be greater than 0");
      return;
    }
    else if(!payload.price){
      window.alert("Price is empty");
      return;
    }




      putDataIntoServer(payload);
    
    props.onClose();
  };



  const changePayeeName=(e)=>{
    setPayload(()=>({...payload,payeeName:e.target.value}));
  }

  const changeProductName=(e)=>{
    setPayload(()=>({...payload,product:e.target.value}));
  }

  const changePriceName=(e)=>{
    setPayload(()=>({...payload,price:e.target.value}));
  }

  const changeDate=(e)=>{
    setPayload(()=>({...payload,setDate:e.target.value}));
  }
 const style = {
  position: 'absolute',
  top: '50%',
  left: '50%',
  transform: 'translate(-50%, -50%)',
  width: 400,
  bgcolor: 'background.paper',
  border: '2px solid #000',
  boxShadow: 24,
  p: 4,
};
console.log("payee name: ",payload.payeeName,"Product purchase: ",payload.product,"Product Price: ",payload.price);
  return (
    <>
      <Modal
      open={true}
      onClose={props.onClose}
      className="MuiModal-backdrop"
      >
        <Box sx={style}>
          <div id ="headingSpace">
          <h2 id="header">Add New Item</h2>
          <p id="disclaimer">Read the below instructions before proceeding:</p>
          <p>Make sure you fill all the fields where * is provided</p>
          </div>

          <form id="form" onSubmit={handleSubmit}>

            <article className="outer-border">
              <label>Name <label style={{color:'red'}}>*</label>: </label>
              <br/>
              <select required
              value={payload.payeeName?payload.payeeName:''}
              onChange={changePayeeName}
              >
                <option value="" defaultChecked>Choose</option>
                <option value="Rahul">Rahul</option>
                <option value="Ramesh">Ramesh</option>
              </select>
                
            </article>

            <article className="outer-border">
              <label>Product Purchased <label style={{color:'red'}}>*</label>:</label>
              <br/>
              <input type="text" value={payload.product} onChange={changeProductName}/>
            </article>

            <article className="outer-border">
              <label>Price <label style={{color:'red'}}>*</label>:</label>
              <br/>
              <input type="number" value={payload.price} onChange={changePriceName}/>
            </article>

            <article className="outer-border">
              <label>Date <label style={{color:'red'}}>*</label>:</label>
              <br/>
              <input type="date" value={payload.setDate} onChange={changeDate}/>
            </article>

            <input type="submit" className="form-button"/>
            <button onClick={props.onClose} className="form-button">Close</button>


          </form>
        
        </Box>
      </Modal>
    </>
  );
};

AddExpense.defaultProps={onClose:()=>{}};
export default AddExpense;

