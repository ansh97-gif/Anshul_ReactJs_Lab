import React, { useEffect, useState } from "react"
import { getDataFromServer } from "../../service/service";
import './showData.css';
import AddExpense from "../AddExpense/AddExpense";
const ShowData = (props) => {
  const [formDataList, setFormDataList] = useState([]);
  const [rahulTotal, setRahulTotal] = useState(0);
  const [rameshTotal, setRameshTotal] = useState(0);
  const [maxPayee,setMaxPayee]=useState('');
  const [deficit,setDeficit]=useState(0);
  const [showAddData,setShowAddData]=useState(false);
  useEffect(() => {
    if(!showAddData){
    let data = getDataFromServer();
    data.then(response => {
      let rahulPay = 0, rameshPay = 0;
      response.map(resp => {
        if (resp.payeeName === 'Rahul')
          rahulPay +=  parseInt(resp.price);
        else if (resp.payeeName === 'Ramesh')
          rameshPay += parseInt(resp.price);
      });
      setMaxPayee(rahulPay>=rameshPay?'Rahul':'Ramesh');
      setRahulTotal(rahulPay);
      setRameshTotal(rameshPay);
      setDeficit(Math.abs(rahulPay-rameshPay));
      setFormDataList(response);
    });
  }
  }, [showAddData]);

  const openAddData=(e)=>{
   e.preventDefault();
   setShowAddData(true);
  }

  const closeAddData=()=>{
   setShowAddData(false);
  }

  return (
    <>
      <header id="page-header"><b>Expense Tracker</b></header>
      <div id="listBody">
        <table className="tableStyle">
          <thead>
            <th className="header">Date</th>
            <th className="header" style={{ width: '40%' }}>Product Purchased</th>
            <th className="header">Price</th>
            <th className="header">Payee</th>
          </thead>
          {
            formDataList && formDataList.map((formData) => (
              <tbody>
                <tr>
                  <td className="spacing date">{formData.setDate}</td>
                  <td className="spacing product">{formData.product}</td>
                  <td className="spacing price">${formData.price}</td>
                  <td className="spacing payee">{formData.payeeName}</td>
                </tr>
              </tbody>
            ))
          }
        </table>
        <span><button id="add-button" onClick={openAddData}>Add</button></span>
      </div>
      <hr />

      <div>
        <span>
          <label className="use-inline" >Total:</label>
          <label>{ parseInt(rahulTotal)+ parseInt(rameshTotal)}</label>
        </span>
        <br/>
        <span>
          <label>Rahul paid:</label>
          <label>{rahulTotal}</label>
        </span>
        <br/>
        <span>
          <label>Ramesh paid:</label>
          <label>{rameshTotal}</label>
        </span>
        <br/>
        <span>
          <label>Pay {maxPayee}: </label>
          <label>{deficit}</label>
        </span>
      </div>
          {showAddData && <AddExpense 
          onClose={closeAddData}
          />}
    </>
  )
};

export default ShowData;
