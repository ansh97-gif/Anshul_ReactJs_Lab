import axios from "axios";

 export const getDataFromServer= async()=>{
    let resp=[];
 resp=await axios.get('http://localhost:3001/items').then(response=>{
  resp= response.data;
  return resp;
  }).catch(err=>{
    console.log("Error: ",err);
  });
 return resp; 
}

export const putDataIntoServer=async(payload)=>{
    let resp= await axios.post('http://localhost:3001/items',payload,{
headers:{
'Content-Type':'application/json'
}
    }
).then(resp=>resp.data);
return resp;
}

