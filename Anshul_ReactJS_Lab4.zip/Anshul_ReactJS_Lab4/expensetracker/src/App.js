import logo from './logo.svg';
import './App.css';
import AddExpense from './components/AddExpense/AddExpense';
import ShowData from './components/ShowData/ShowData';
import { Link, Route, Routes } from 'react-router-dom';

function App() {
  return (
    <>
      <Routes>
      <Route path="/" element={<ShowData/>}/>
      <Route path="/add" element={<AddExpense></AddExpense>}/>
      </Routes>
    </>
  );
}

export default App;
